$(document).ready(function() {
    let dataList;
    let countFirstFilter = 0;
    let countSecondFilter = 0;
    $.ajax({
        type: "Get",
        url: "data.json",
        dataType: "json",
        contentType: "application/json",    
        data: {},
        success: function(data) {
            console.log(data);
             dataList = data;
            for(i=0;i<dataList.length;i++){
        $('#myTable').append( '<tr><td>' + dataList[i].id  + '</td><td class="name">' + dataList[i].character + '</td><td>' + dataList[i].actor + '</td><td>' + dataList[i].movie  +  '</td></tr>' );
    }
    
        },
        error: function(){
            alert("json not found");
        }
    });
    
    $("#search").keyup(function () {
        console.log("test");
        var data = this.value.toLowerCase().split(" ");
        console.log("data", data); 
        $('#myTable tr').each(function(index) {
            console.log("row",this);
            console.log("index", index, data);
        var customerId = $(this).find('.name').html();    
        // console.log("td value", customerId);
        if (customerId.toLowerCase().indexOf(data[0]) != -1 && data[0] !== "") {
            console.log("match", customerId)
                    $(this).addClass('highlighted');
    
                } else {
                    $(this).removeClass('highlighted');   
                }
    
     });
    
        
    
    
       
    }) 
    
    $(".firstFilter").on('click', function(){
        console.log("first filter");
        $('#myTable tr').each(function(index) {
            $(this).removeClass('hide');
        });
        $('#myTable tr').each(function(index) {
            // console.log("row",this);
            // console.log("index", index, data);
        var customerId = $(this).find('.name').html();    
        console.log("td value", customerId.charCodeAt(0));    
        if (customerId.charCodeAt(0) <= 77) {
            
            countFirstFilter++;      
            // console.log("match count", count);
                    // $(this).addClass('visible');
    
                } else {
                    console.log("match value", customerId.toLowerCase()[0].charCodeAt(0), "M".charCodeAt(0))
                    $(this).addClass('hide');   
                }
        $('.firstFilter').html(`A-M (${countFirstFilter})`);
        $('.firstFilter').attr('disabled', true);
        countSecondFilter = 0;
        $('.secondFilter').attr('disabled', false);
    
     });
    })
    
    $(".secondFilter").on('click', function(){
        console.log("second filter");
        console.log("first filter");
        $('#myTable tr').each(function(index) {
            $(this).removeClass('hide');
        });
        $('#myTable tr').each(function(index) {
            // console.log("row",this);
            // console.log("index", index, data);
        var customerId = $(this).find('.name').html();    
        console.log("td value", customerId);
        if (customerId.charCodeAt(0) >= 78) {
            console.log("match", customerId)
            countSecondFilter++;
                    // $(this).addClass('visible');
    
                } else {
                    console.log("match value", customerId.toLowerCase()[0].charCodeAt(0), "M".charCodeAt(0))
                    $(this).addClass('hide');   
                }
                $('.secondFilter').html(`N-Z (${countSecondFilter})`);
                $('.secondFilter').attr('disabled', true);
                countFirstFilter = 0;
                $('.firstFilter').attr('disabled', false);
     });
    })
    });